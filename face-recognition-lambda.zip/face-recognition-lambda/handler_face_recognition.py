import boto3
import os
import cv2
from PIL import Image
from facenet_pytorch import MTCNN, InceptionResnetV1
import torch

# Ensure PyTorch caches models in /tmp
os.environ['TORCH_HOME'] = '/tmp/torch'  # HIGHLIGHTED: Set TORCH_HOME to ensure model caching uses /tmp

# Initialize AWS S3 client
s3_client = boto3.client('s3')

# Initialize face detection and recognition models
mtcnn = MTCNN(image_size=240, margin=0, min_face_size=20)
resnet = InceptionResnetV1(pretrained='vggface2').eval()

def lambda_handler(event, context):
    """
    AWS Lambda handler function for face recognition.

    Parameters:
        event: dict, contains 'bucket_name' and 'image_file_name'
        context: LambdaContext, AWS Lambda uses this to provide runtime information

    Returns:
        dict: Result with status and recognized name
    """
    print(f"Step 1: Received event: {event}")

    # Extract parameters from the event
    bucket_name = event.get('bucket_name')
    image_file_name = event.get('image_file_name')

    if not bucket_name or not image_file_name:
        print("Error: Missing required parameters 'bucket_name' or 'image_file_name'")
        return {"status": "Error", "message": "Missing required parameters"}

    print(f"Step 2: Extracted parameters - Bucket: {bucket_name}, File: {image_file_name}")

    # Define local paths for processing
    local_image_path = f"/tmp/{image_file_name}"  # Already using /tmp for temporary storage
    local_data_path = "/tmp/data.pt"  # Already using /tmp for temporary storage
    output_bucket_name = bucket_name.replace("-stage-1", "-output")
    output_file_name = f"{os.path.splitext(image_file_name)[0]}.txt"
    output_file_path = f"/tmp/{output_file_name}"  # Already using /tmp for temporary storage

    print(f"Step 3: Defined paths - Local Image Path: {local_image_path}, Output Path: {output_file_path}")

    try:
        # Download the image from S3
        print(f"Step 4: Downloading image from S3 bucket: {bucket_name}, Key: {image_file_name}")
        s3_client.download_file(bucket_name, image_file_name, local_image_path)
        print(f"Step 5: Successfully downloaded image: {image_file_name}")

        # Download the data.pt file from S3
        print(f"Step 6: Downloading data.pt from S3 bucket: '1229028439-embeddings'")
        s3_client.download_file("1229028439-embeddings", "data.pt", local_data_path)
        print(f"Step 7: Successfully downloaded data.pt")

        # Perform face recognition
        print(f"Step 8: Processing the image for face recognition")
        recognized_name = process_image(local_image_path, local_data_path)
        print(f"Step 9: Face recognition result - Recognized Name: {recognized_name}")

        # Write the recognized name to a text file
        print(f"Step 10: Writing recognized name to output file: {output_file_path}")
        with open(output_file_path, "w") as f:
            f.write(recognized_name)
        print(f"Step 11: Successfully wrote recognized name to file")

        # Upload the result to the output bucket
        print(f"Step 12: Uploading result to S3 bucket: {output_bucket_name}, Key: {output_file_name}")
        s3_client.upload_file(output_file_path, output_bucket_name, output_file_name)
        print(f"Step 13: Successfully uploaded result to S3")

    except Exception as e:
        print(f"Error during processing: {e}")
        return {"status": "Error", "message": str(e)}

    finally:
        # Cleanup temporary files
        print("Step 14: Cleaning up temporary files")
        cleanup([local_image_path, output_file_path, local_data_path])

    print("Step 15: Processing completed successfully")
    return {"status": "Success", "recognized_name": recognized_name}

def process_image(image_path, data_path):
    print(f"Processing image: {image_path} with data from: {data_path}")
    
    # Load image
    image = cv2.imread(image_path)
    img_pil = Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
    
    # Perform face detection
    face, _ = mtcnn(img_pil, return_prob=True)
    if face is None:
        print("No face detected in the image.")
        return "No Match Found"
    
    # Compute face embedding
    print("Computing face embedding...")
    face_embedding = resnet(face.unsqueeze(0)).detach()
    
    # Load saved embeddings
    saved_data = torch.load(data_path)  # Already using /tmp for saved model data
    print(f"Type of data.pt content: {type(saved_data)}")

    # Check if data.pt is a tuple or list
    if isinstance(saved_data, (tuple, list)) and len(saved_data) == 2:
        embedding_list, name_list = saved_data  # Unpack the tuple/list
    else:
        raise ValueError("Unexpected data.pt format: Expected a tuple with embeddings and names")

    # Match embedding with the database
    print("Matching embedding with database...")
    distances = [torch.dist(face_embedding, emb).item() for emb in embedding_list]
    min_distance_idx = distances.index(min(distances))
    print(f"Minimum distance found: {min(distances)}")
    
    return name_list[min_distance_idx] if min(distances) < 1.0 else "No Match Found"

def cleanup(paths):
    """
    Delete temporary files to clean up /tmp directory.

    Parameters:
        paths: list of str, file paths to delete
    """
    for path in paths:
        if os.path.exists(path):
            os.remove(path)
            print(f"Deleted temporary file: {path}")
