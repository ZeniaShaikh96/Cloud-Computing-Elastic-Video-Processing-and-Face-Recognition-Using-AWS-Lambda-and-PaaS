import boto3
import os
import subprocess
import json

s3_client = boto3.client('s3')
lambda_client = boto3.client('lambda')

def lambda_handler(event, context):
    print(f"Received Event: {event}")

    # Extract bucket and object key from the event
    source_bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']
    print(f"Source Bucket: {source_bucket}, Key: {key}")

    # Define paths
    local_video_path = f"/tmp/{key}"
    video_name = os.path.splitext(os.path.basename(key))[0]
    output_image_path = f"/tmp/{video_name}.jpg"

    # Download the video from S3
    s3_client.download_file(source_bucket, key, local_video_path)
    print(f"Downloaded video: {key}")

    # Extract a single frame using FFmpeg
    ffmpeg_command = [
        "ffmpeg",
        "-i", local_video_path,
        "-vframes", "1",
        output_image_path
    ]
    try:
        subprocess.run(ffmpeg_command, check=True)
        print(f"Frame extracted: {output_image_path}")
    except subprocess.CalledProcessError as e:
        print(f"FFmpeg error: {e}")
        return {"status": "Error", "message": str(e)}

    # Upload the frame to the Stage-1 bucket
    destination_bucket = source_bucket.replace("-input", "-stage-1")
    output_key = f"{video_name}.jpg"
    s3_client.upload_file(output_image_path, destination_bucket, output_key)
    print(f"Uploaded frame to: {destination_bucket}/{output_key}")

    # # Invoke the face-recognition Lambda function
    face_recognition_payload = {
        "bucket_name": destination_bucket,
        "image_file_name": output_key
    }
    try:
        lambda_client.invoke(
            FunctionName="face-recognition",
            InvocationType="Event",  # Asynchronous invocation
            Payload=json.dumps(face_recognition_payload)
        )
        print(f"Invoked face-recognition function with payload: {face_recognition_payload}")
    except Exception as e:
        print(f"Error invoking face-recognition function: {e}")
        return {"status": "Error", "message": str(e)}

    # Cleanup local files
    os.remove(local_video_path)
    os.remove(output_image_path)
    print("Cleanup completed")

    return {"status": "Success"}
